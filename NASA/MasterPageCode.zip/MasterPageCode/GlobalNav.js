var globalNavArray;
$(document).ready(function(){
/******************************* Function to get create the link Object ********************************************/
/******************************* Input is linkNode from Global Navigation List *************************************/
function GlobalLinkObj(linkNode) {
    this.title = linkNode.attr("ows_Title") || "";
    this.link = linkNode.attr("ows_Link") || "";
    this.displayOrder = linkNode.attr("ows_DisplayOrder") || "";
    this.parent = linkNode.attr("ows_Parent") || "";
    this.audience = linkNode.attr("ows_Audience") || "";
    this.newTab = linkNode.attr("ows_NewTab") || "";
    this.tileContainer = linkNode.attr("ows_TileContainer") || "";
    this.children = [];
    this.id = linkNode.attr("ows_ID");
};

/******************************* Function to handle the results from GetListItems for Global Navigation List ********************************************/
/******************************* Input is results data  from Global Navigation List *********************************************************************/
function GetGlobalNavigationLinks(){
	var dfd = $.Deferred(),
		navLinks = [];
	
    $().SPServices({
        operation: "GetListItems",
        async: true,
        webURL: hpdURL,
        listName: "Global Navigation",
        viewName: "",
        CAMLQuery: "",
        rowLimit: 20000,
        completefunc: function(xData, status) {
            $(xData.responseXML).SPFilterNode("z:row").each(function() {
               navLinks.push(new GlobalLinkObj($(this)));
            });
			
			dfd.resolve(navLinks);
        }
    });
	
	return dfd.promise();
}

/******************************* Function to get all of the User's information ****************************************************************/
/******************************* Input is the web url of the current site *********************************************************************/
function GetUserInfo(webUrl) {
    var dfd = $.Deferred();
	
	$.ajax({
        url: webUrl + '/_api/web/currentuser/?$expand=groups',
        method: "GET",
        contentType: "application/json;odata=verbose",
        headers: {
            "Accept": "application/json;odata=verbose"
        },
        success: function(data){
			dfd.resolve(data);
		},
        error: function(){
			console.log("Error getting user information");
		}
    });
	
	return dfd.promise();
}


/****************************************************************** Function to get list items *****************************************************************************/
/****************************************************************** Input is the web url of the current site, target list and query ****************************************/
function GetListItems(webURL, list, query) {
	var results = {},
		dfd = $.Deferred();
		
	$().SPServices({
		operation: "GetListItems",
		async: true,
		webURL: webURL,
		listName: list,
		viewName: "",
		CAMLQuery: query,
		rowLimit: 20000,
		completefunc: function(data, status) {
			results.data = data;
			results.status = status;
			
			dfd.resolve(results);
		}
	});
	return dfd.promise();
}


/****************************************************************** Load all the data for the top nav ************************************************************************/
$.when(GetGlobalNavigationLinks(), GetUserInfo(L_Menu_BaseUrl),
	GetListItems(hpdURL + "/Missions", "Heliophysics Mission Data", '<Query><Where><IsNotNull><FieldRef Name="URL" /></IsNotNull></Where><OrderBy><FieldRef Name="Title" Ascending="False"/></OrderBy></Query>'),
	GetListItems(hpdURL + "/ROSES", "ROSES Elements Data", ''),
	GetListItems(hpdURL + "/ROSES", "ROSES Element Profiles", '<Query><Where><Eq><FieldRef Name="Active" /><Value Type="Integer">1</Value></Eq></Where><OrderBy><FieldRef Name="Title" Ascending="True"/></OrderBy></Query>'))
.then(function(navigationLinks, userInfo, missionsLinksResults, rosesElementsResults, rosesElementProfileResults){
	
	// Mission Subsite Links
	var missionLink = navigationLinks.filter(function(link){return link.title === "Missions"})[0];

	$(missionsLinksResults.data.responseXML).SPFilterNode("z:row").each(function(){
		var subsite = $(this).attr("ows_Subsite"),
			url = $(this).attr("ows_URL"),
			missionSubsiteLinkObj = new CustomLinkObj(subsite, "", "", false);
		
		missionSubsiteLinkObj.children.push(new CustomLinkObj(subsite + " Overview", url, "", false)); 
		missionSubsiteLinkObj.children.push(new CustomLinkObj("Document Libraries", "", "", false));
		missionSubsiteLinkObj.children.push(new CustomLinkObj("View Mission Requirements", "", "", true));
		missionSubsiteLinkObj.children.push(new CustomLinkObj("Manage Mission Requirements", "", "", true));
		missionLink.children.push(missionSubsiteLinkObj);
	});
	
	// ROSES Links
	var isElementsRecurringObj = {},
		recurringLinks = navigationLinks.filter(function(link){return link.title === "Recurring Elements"})[0],
		nonRecurringLinks = navigationLinks.filter(function(link){return link.title === "Non-Recurring Elements"})[0];
	
	$(rosesElementsResults.data.responseXML).SPFilterNode("z:row").each(function(){
		var element = $(this).attr("ows_Title"),
			recurring = $(this).attr("ows_Recurring") === "1" ? true : false;
			
		
		isElementsRecurringObj[element] = recurring;
	});
	
	$(rosesElementProfileResults.data.responseXML).SPFilterNode("z:row").each(function(){
		var elementProfile = $(this).attr("ows_Title"),
			id = $(this).attr("ows_ID"),
			rosesElementProfileLinkObj = new CustomLinkObj(elementProfile, "", "", false),
			element = $(this).attr("ows_ROSESElement").split(";#")[1],
			recurring = isElementsRecurringObj[element];
			
		rosesElementProfileLinkObj.children.push(new CustomLinkObj("Import NSPIRES Data", "", "", false)); 
		rosesElementProfileLinkObj.children.push(new CustomLinkObj("View Panels", "", "", false));
		rosesElementProfileLinkObj.children.push(new CustomLinkObj("Reassign Proposals", "", "", true));
		rosesElementProfileLinkObj.children.push(new CustomLinkObj("Manage Panelists", "", "", true));
		rosesElementProfileLinkObj.children.push(new CustomLinkObj("Dashboards", "", "", true));
		if(recurring) {
			recurringLinks.children.push(rosesElementProfileLinkObj);
		} else {
			nonRecurringLinks.children.push(rosesElementProfileLinkObj);
		}
	});
	
	navigationLinks.filter(function(link){return link.parent}).forEach(function(link){
		var parent = navigationLinks.filter(function(nl){return nl.title === link.parent.split(";#")[1]})[0];
		parent.children.push(link);
	});
	
	globalNavArray = navigationLinks.filter(function(link){return !link.parent});
	
	var globalNavHTML = '<ul class="navbar-nav">';
	
	globalNavArray.forEach(function(navItem) {
		globalNavHTML += '<li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">' + navItem.title + '</a>';
		
		if (navItem.children.length) {
			globalNavHTML += GetChildrenHTML(navItem.children);
		}
		
		globalNavHTML += "</li>";
	});
	
	globalNavHTML += "</ul>";
	
	document.getElementById("globalNav").innerHTML += globalNavHTML;
});



/****************************************************************** Function to Create Items not included in the Global Nav list *****************************************************************************/
/****************************************************************** Title (string) is the display name, url (string) is the link, audience (string) is who can see it, and newTab is should it open a new tab (bool) ****************************************/
	function CustomLinkObj(title, url, audience, newTab) {
		try{
			this.title = title || "";
			this.link = url || "";
			this.newTab = newTab;
			this.audience = audience;
			this.children = [];
		} catch (e) {
                
            }
	}
	/****************************************************** Function to Get all the information we need from Element Profiles **************************************************************/
	/******************************************************  ****************************************/
	function ElementProfileObj(title, url, audience, newTab) {
		try{
			this.title = title || "";
			this.link = url || "";
			this.newTab = newTab;
			this.audience = audience;
			this.children = [];
		} catch (e) {
                
            }
	}
	
	function GetChildrenHTML(childrenArray) {
		var childHTML = '<ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">';
		
		childrenArray.forEach(function(navItem) {
			if (!navItem.children.length) {
				childHTML += '<li><a class="dropdown-item" href="' + navItem.link + '">' + navItem.title + '</a></li>'
			}
			
			else {
				childHTML += '<li class="dropdown-submenu"><a class="dropdown-item dropdown-toggle" href="#">' + navItem.title + '</a>';
				childHTML += GetChildrenHTML(navItem.children);
				childHTML += '</li>';
			}
    });

    childHTML += "</ul>";
    return childHTML;
  }
});