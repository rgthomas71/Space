// Global variables used in other files.
var missionSite, rosesSite, hpdURL, currYear, missionURL, rOSESURL, persistantToastr;

// Find out if we're on missions, ROSEs or top level.
if (window.location.href.toLowerCase().indexOf("/roses/") !== -1)
	rosesSite = true;
else if (window.location.href.toLowerCase().indexOf("/hpd/sitepages/welcome.aspx") === -1)
	missionSite = true;

var currentUser = "";
var currentUserName = "";
var currentUserGroups = [];


//Begin - Add the permissions to the persistantToastr object.  
  persistantToastr.options = {
          	"timeOut": "0",
  			"extendedTimeOut": "0"
  		  };
   //End - Add the permissions to the persistantToastr objec
   
   
$(document).ready(function(){
	hpdURL = L_Menu_BaseUrl.substring(0, L_Menu_BaseUrl.toLowerCase().indexOf("hpd")+3);
	missionsURL = hpdURL + "/Missions/";
	ROSESURL = hpdURL + "/ROSES/"

});




/*$(document).ready(function(){
//SP.SOD.executeFunc('sp.js', '', function() {
    

	// Get the current user ID and group memberships
	getCurrentUser();
	getCurrentUserGroups();
	audienceTopNav();
	
	//Hide IncludeInQuadChart and Content TYpe Input everywhere, for the time being.
	$("h3#IncludeInQuadChart").parent().parent().hide();
	$("select[title='Content Type']").parent().parent().hide();
	
	//Get top level site urls as a lot of lists are located there.
	hpdURL = L_Menu_BaseUrl.substring(0, L_Menu_BaseUrl.toLowerCase().indexOf("hpd")+3);
	missionsURL = hpdURL + "/Missions/";
	ROSESURL = hpdURL + "/ROSES/"
	// Current year, used for ROSES elements.
	var date = new Date();
	currYear = date.getYear() + 1900;
	// Get ROSES elements and put them in the top bar. Less Admin work later.
	GetROSESTopNavElements()
	
	// Get Mission lists created and put them in the top bar.
	GetMissionsTopNavElements();
  // Hide footer in dialogs.
  if (window.location.href.toLowerCase().indexOf("isdlg") !== -1) {
  	$("#pageFooter").css("display", "none");
  }
  	



	// Dynamically add ROSES Elements links to top navigation
	function GetROSESTopNavElements() {
		try{
			var rosesHTML = "";
	
			var rosesElementsData = [];
	
			$().SPServices({
				operation: "GetListItems",
				async: false,
				webURL: hpdURL + "/ROSES",
				listName: "ROSES Elements Data",
				viewName: "",
				CAMLQuery: '<Query><Where><Eq><FieldRef Name="Active" /><Value Type="Integer">1</Value></Eq></Where></Query>',
				rowLimit: 20000,
				completefunc: function(xData) {
					
					$(xData.responseXML).find("z\\:row").each(function() {
						var element = $(this).attr("ows_Title");
						if ($(this).attr("ows_Recurring") === "1") 
							rosesElementsData[element] = true;
						else 
							rosesElementsData[element] = false;
					});
		    	}
			});
	
	
		
			$().SPServices({
				operation: "GetListItems",
				async: false,
				webURL: hpdURL + "/ROSES",
				listName: "ROSES Element Profiles",
				viewName: "",
				CAMLQuery: '<Query><Where><Eq><FieldRef Name="Active" /><Value Type="Integer">1</Value></Eq></Where><OrderBy><FieldRef Name="Title" Ascending="True"/></OrderBy></Query>',
				rowLimit: 20000,
				completefunc: function(xData) {
	
					console.log("\n\n***** responseText *****\n\n" + xData.responseText + "\n\n");
	
					var recurringItems = [],
						nonRecurringItems = [];
					
					$(xData.responseXML).find("z\\:row").each(function() {
						var item = [];
	
						item.id = $(this).attr("ows_ID");
						item.title = $(this).attr("ows_Title");
						item.year = $(this).attr("ows_Year");
						item.element = $(this).attr("ows_ROSESElement").split(";#")[1]	;
	
						if (rosesElementsData[item.element])
							recurringItems.push(item);
						else 
							nonRecurringItems.push(item)
					});
	
					var rosesHTML = "";
			
					//Non-Recurring Elements
					$(nonRecurringItems).each(function(){
					
						rosesHTML = '<li class="dropdown-submenu"><a class="dropdown-item dropdown-toggle" href="#">' + this.title + '</a>';
						rosesHTML = rosesHTML + '<ul class="dropdown-menu">';	
						// Audience the panel planning tool links to HPD Owners and ROSES Tool Users
							if ( (currentUserGroups.indexOf("HPD Owners") >= 0) || (currentUserGroups.indexOf("ROSES Tools Users") >= 0) ) {
							rosesHTML = rosesHTML + '<li><a class="dropdown-item" href="/teams/SMD/HPD/ROSES/Pages/Tools.aspx/PanelPlanning/' + this.id + '/ImportNSPIRESData" target="blank">Import NSPIRES Data</a></li>';
							rosesHTML = rosesHTML + '<li><a class="dropdown-item" href="/teams/SMD/HPD/ROSES/Pages/Tools.aspx/PanelPlanning/' + this.id + '/ViewPanels" target="blank">View Panels</a></li>';
							rosesHTML = rosesHTML + '<li><a class="dropdown-item" href="/teams/SMD/HPD/ROSES/Pages/Tools.aspx/PanelPlanning/' + this.id + '/ReassignProposals" target="blank">Reassign Proposals</a></li>';
							rosesHTML = rosesHTML + '<li><a class="dropdown-item" href="/teams/SMD/HPD/ROSES/Pages/Tools.aspx/PanelPlanning/' + this.id + '/ManagePanelists" target="blank">Manage Panelists</a></li>';							
							rosesHTML = rosesHTML + '<li><a class="dropdown-item" href="/teams/SMD/HPD/ROSES/Pages/Tools.aspx/PanelPlanning/' + this.id + '/Dashboards" target="blank">Dashboards</a></li>';
							
						}
						rosesHTML = rosesHTML + '</ul>';
						rosesHTML = rosesHTML + '</li>';
					
						$("#topNavROSESNonRecurring").append(rosesHTML);
					});
	
					// Recurring Elements
					$(recurringItems).each(function(){
	
						rosesHTML = '<li class="dropdown-submenu"><a class="dropdown-item dropdown-toggle" href="#">' + this.title + '</a>';
						rosesHTML = rosesHTML + '<ul class="dropdown-menu">';	
						// Audience the panel planning tool links to HPD Owners and ROSES Tool Users
						if ( (currentUserGroups.indexOf("HPD Owners") >= 0) || (currentUserGroups.indexOf("ROSES Tools Users") >= 0) ) {
							rosesHTML = rosesHTML + '<li><a class="dropdown-item" href="/teams/SMD/HPD/ROSES/Pages/Tools.aspx/PanelPlanning/' + this.id + '/ImportNSPIRESData" target="blank">Import NSPIRES Data</a></li>';
							rosesHTML = rosesHTML + '<li><a class="dropdown-item" href="/teams/SMD/HPD/ROSES/Pages/Tools.aspx/PanelPlanning/' + this.id + '/ViewPanels" target="blank">View Panels</a></li>';
							rosesHTML = rosesHTML + '<li><a class="dropdown-item" href="/teams/SMD/HPD/ROSES/Pages/Tools.aspx/PanelPlanning/' + this.id + '/ReassignProposals" target="blank">Reassign Proposals</a></li>';
							rosesHTML = rosesHTML + '<li><a class="dropdown-item" href="/teams/SMD/HPD/ROSES/Pages/Tools.aspx/PanelPlanning/' + this.id + '/ManagePanelists" target="blank">Manage Panelists</a></li>';								
							rosesHTML = rosesHTML + '<li><a class="dropdown-item" href="/teams/SMD/HPD/ROSES/Pages/Tools.aspx/PanelPlanning/' + this.id + '/Dashboards" target="blank">Dashboards</a></li>';
						}
						rosesHTML = rosesHTML + '</ul>';
						rosesHTML = rosesHTML + '</li>';
	
						$("#topNavROSESRecurring").append(rosesHTML);
					});
		    	}
			});
		} catch (e) {
                
            }
	}


	// Dynamically add Missions links to top navigation
	function GetMissionsTopNavElements() {
		try{
			var missionHTML = "";
		
			$().SPServices({
				operation: "GetListItems",
				async: false,
				webURL: hpdURL + "/Missions",
				listName: "Heliophysics Mission Data",
				viewName: "",
				CAMLQuery: '<Query><Where><IsNotNull><FieldRef Name="URL" /></IsNotNull></Where><OrderBy><FieldRef Name="Title" Ascending="False"/></OrderBy></Query>',
				rowLimit: 20000,
				completefunc: function(xData) {
					$("div[id*='TopNavigationMenu'] .menu-item-text:contains('Missions')").parent().parent().next().prepend('<hr>');							
					$(xData.responseXML).find("z\\:row").each(function() {
					
						var subsite = $(this).attr("ows_Subsite");
						var pe = $(this).attr("ows_ProgramExecutive");
						if (pe == undefined) pe = "";
						
						var manageMission = "/teams/SMD/HPD/Missions/Pages/MissionRequirements.aspx/" + subsite + "/ManageMissionRequirements/I4Requirements";
						var viewMission = "/teams/SMD/HPD/Missions/Pages/MissionRequirements.aspx/" + subsite + "/View";
						
//										/teams/SMD/HPD/Missions/Pages/MissionRequirements.aspx/SolarOrbiter/View
						
						
						missionHTML = '<li class="dropdown-submenu"><a class="dropdown-item dropdown-toggle" href="#">' + $(this).attr("ows_Title") + '</a>';
						missionHTML = missionHTML + '<ul class="dropdown-menu">';
						missionHTML = missionHTML + '<li><a class="dropdown-item" href="' + $(this).attr("ows_URL") + '">Overview</a></li>';
						//missionHTML = missionHTML + '<li><a class="dropdown-item" href="' + $(this).attr("ows_URL").replace("Home.aspx", "DiscussionFeed.aspx") + '">Discussion Feed</a></li>';
						missionHTML = missionHTML + '<li><a class="dropdown-item" href="' + $(this).attr("ows_URL").replace("Home.aspx", "DocumentLibraries.aspx") + '">Document Libraries</a></li>';
						missionHTML = missionHTML + '<li><a class="dropdown-item" href="' + viewMission + '" target="_blank">View Mission Requirements</a></li>';

						if ( (currentUserName == pe.split(";#")[1]) ||  (currentUserGroups.indexOf("HPD Owners") >= 0) ) {
//						if (currentUserName == pe.split(";#")[1]) {
							missionHTML = missionHTML + '<li><a class="dropdown-item" href="' + manageMission + '" target="_blank">Manage Mission Requirements</a></li>';
						}
						
						//if ( (currentUserGroups.indexOf("HPD Owners") >= 0) || (currentUserGroups.indexOf($(this).attr("ows_Subsite")) >= 0) ) {
						//	missionHTML = missionHTML + '<li><div class="dropdown-divider"></div></li>';
						//	missionHTML = missionHTML + '<li><a class="dropdown-item" href="/teams/SMD/HPD/SiteAssets/SiteCode/MissionSpecific/AdminConsole/AdminConsole.aspx#/Home/' + $(this).attr("ows_Subsite") + '" target="_blank">Manage Permissions</a></li>';
						//}
						
						missionHTML = missionHTML + '</ul>';
						missionHTML = missionHTML + '</li>';
						
						if (missionHTML != "") {
							$("#topNavMissions li:eq(2)").after(missionHTML);
						}
					});
				}
			});
		} catch (e) {
                
            }
	}


	// Sets the gobal currentUser variable to the ID of the currently logged in user
	function getCurrentUser() {
		try{
			currentUser = $().SPServices.SPGetCurrentUser({
				fieldName: "Name",
				debug: false
			});	
			
			currentUserName = $().SPServices.SPGetCurrentUser({
				fieldName: "Title",
				debug: false
			});
		 } catch (e) {
                
            }
	}
	

	// Populates the global currentUserGroups array with the names of the groups of which the current user is a member
	function getCurrentUserGroups() {
		try{
			$().SPServices({
				operation: "GetGroupCollectionFromUser",
				async: false,
				userLoginName: currentUser,
				completefunc: function (xData, Status) {
			 
			        $(xData.responseXML).find("Group").each(function () {
			            currentUserGroups.push($(this).attr("Name"));
			        });
			    }
			});	
		} catch (e) {
                
            }
	}


	function audienceTopNav() {
		try{
	
			// Security trim the HAL Planning menu item
			if (	(currentUserGroups.indexOf("HPD Owners") == -1) &&
					(currentUserGroups.indexOf("HAL Planning Owners") == -1) &&
					(currentUserGroups.indexOf("HAL Planning Members") == -1)
				) {
	
				$("#topnavHALPlanning").hide();
			}
	
			// Security trim the Admin Console menu item
			if (currentUserGroups.indexOf("HPD Owners") == -1) {
				$("#topnavAdminConsole").hide();
			}
			
			// Security trim the Advisory Committees menu item
			if (	(currentUserGroups.indexOf("HPD Owners") == -1) &&
					(currentUserGroups.indexOf("Advisory Committee Members") == -1)
				) {
	
				$("#topnavAdvisory").hide();
			}
	
			// Security trim the FACA Member Management menu item
			if (	(currentUserGroups.indexOf("HPD Owners") == -1) &&
					(currentUserGroups.indexOf("FACA Member Management Members") == -1)
				) {
	
				$("#topnavAdvisory-FACA").hide();
			}
			
			// Security trim the HPAC menu item
			if (	(currentUserGroups.indexOf("HPD Owners") == -1) &&
					(currentUserGroups.indexOf("HPAC Members") == -1)
				) {
	
				$("#topnavAdvisory-HPAC").hide();
			}
	
			// Security trim the Senior Reviews menu item
			if (	(currentUserGroups.indexOf("HPD Owners") == -1) &&
					(currentUserGroups.indexOf("Senior Reviews Members") == -1)
				) {
	
				$("#topnavAdvisory-Senior").hide();
			}
	
			// Security trim the STDT menu item
			if (	(currentUserGroups.indexOf("HPD Owners") == -1) &&
					(currentUserGroups.indexOf("STDT Members") == -1)
				) {
	
				$("#topnavAdvisory-STDT").hide();
			}
		} catch (e) {
                
            }
	}
	
});	*/