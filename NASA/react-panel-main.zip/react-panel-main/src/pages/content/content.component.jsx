import './content.styles.scss';
import Panel from '../panel/panel.component';

export default function Content() {
    return (
        <main>
            <Panel />
        </main>
    );
}