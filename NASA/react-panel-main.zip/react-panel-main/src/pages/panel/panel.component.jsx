import './panel.styles.scss';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faInfoCircle as info, faBlackboard as blackboard, faPeopleGroup as group, faDownload as download, faDisplay, faCheckToSlot as checklist } from '@fortawesome/free-solid-svg-icons';
import { useState } from 'react';
import BarChangeElement from '../../components/bar-change-element/bar-change-element.component';
import BarOverview from '../../components/bar-overview/bar-overview.component';
import BarPanels from '../../components/bar-panels/bar-panels.component';

export default function Panel() {
    const [showBar, setShowBar] = useState(true);
    const [navSection, setNavSection] = useState('change-element');
    return (
        <div className="panel-container">
            <div className="left-nav-bar">
                <div className={`button ${navSection === 'change-element' ? 'active' : ''}`} onClick={() => {
                    if (!showBar) setShowBar(true);
                    if (navSection !== 'change-element') setNavSection('change-element');
                }}><span>HGIO</span><span>2019</span></div>
                <div className={`button ${navSection === 'overview' ? 'active' : ''}`} onClick={() => {
                    if (!showBar) setShowBar(true);
                    if (navSection !== 'overview') setNavSection('overview');
                }}><span className="icon"><FontAwesomeIcon icon={info} /></span><span>Overview</span></div>
                <div className={`button ${navSection === 'panels' ? 'active' : ''}`} onClick={() => {
                    if (!showBar) setShowBar(true);
                    if (navSection !== 'panels') setNavSection('panels');
                }}><span className="icon"><FontAwesomeIcon icon={blackboard} /></span><span>Panels</span></div>
            </div>
            <div className={`panel-selection ${!showBar ? 'hidden' : ''}`}>
                {navSection === 'change-element' ? <BarChangeElement setShowBar={setShowBar} /> : null}
                {navSection === 'overview' ? <BarOverview setShowBar={setShowBar} /> : null}
                {navSection === 'panels' ? <BarPanels setShowBar={setShowBar} /> : null}
            </div>
            <div className="panel-info">
                <div className="trail"><a href="#">ROSES</a> /</div>
                <h1>ROSES Tools</h1>
                <div className="panel-content">
                    <div className="tools-container">
                        <div className="tool">
                            <span>Program Officer Dashboard</span>
                            <span className="dropdown"><FontAwesomeIcon icon={group} /></span>
                            <div className="inner-links">
                                <div>Panel Roles, Dates, Location</div>
                                <div>SRP Panel Funding Splits</div>
                                <div>SRP Compilation</div>
                            </div>
                        </div>
                        <div className="tool">
                            <span>Import Data</span>
                            <span><FontAwesomeIcon icon={download} /></span>
                        </div>
                        <div className="tool">
                            <span>Panel Planning</span>
                            <span className="dropdown"><FontAwesomeIcon icon={checklist} /></span>
                            <div className="inner-links">
                                <div>View & Reassing Proposals</div>
                                <div>Find & Manage Panelists</div>
                            </div>
                        </div>
                        <div className="tool">
                            <span>Panel Official Dashboar</span>
                            <span className="dropdown"><FontAwesomeIcon icon={faDisplay} /></span>
                            <div className="inner-links">
                                <div>Scoring Panels</div>
                                <div>Panel SRS Creation</div>
                            </div>
                        </div>
                    </div>
                    <p>Select Panel to Begin</p>
                </div>
            </div>
        </div>
    );
}