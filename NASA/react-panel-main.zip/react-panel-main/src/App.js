import './App.scss';
import { Routes } from 'react-router-dom';
import Nav from './components/nav/nav.component';
import Content from './pages/content/content.component';
import Footer from './components/footer/footer.component';

function App() {
  return (
    <div className="container">
      <Nav />
      <Content />
      <Footer />
    </div>
  );
}

export default App;
