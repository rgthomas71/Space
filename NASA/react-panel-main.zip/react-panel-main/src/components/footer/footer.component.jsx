import './footer.styles.scss';
import logo from '../../nasa-logo.svg';

export default function Footer() {
    return (
        <footer>
            <img src={logo} width="60" alt="NASA Logo" />
            <div className="disclaimer">
            <a href="#">Privacy Policy</a> and <a href="#">Important Notices</a><br/>
            <br />Editor: Ragaban, Aadel
            <br />NASA Official: New, Michael
            <br />Sharepoint Support: KIAC CARE Center, 321-867-KIAC, option 3
            <br />Last Updated: April 13, 2022
            </div>
        </footer>
    );
}