import './bar-overview.styles.scss';

export default function BarOverview({ setShowBar }) {
    return (
        <div className="overview">
            <h2><span>Overview</span><button onClick={() => setShowBar(false)}>Close</button></h2>
            <section>
                <h3>Grading Scale</h3>
                <p>Current Scale: 1 - 9</p>
            </section>
            <section>
                <h3>Program Officer</h3>
                <p>Rasmi, Mazin [USA]</p>
            </section>
            <section>
                <h3>Backup Program Officer</h3>
                <p>N/A</p>
            </section>
            <section>
                <h3>Totals</h3>
            </section>
            <section>
                <h3>Dates</h3>
            </section>
        </div>
    );
}