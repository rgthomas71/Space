import './nav.styles.scss';
import logo from '../../nasa-logo.svg';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faGear as gear, faArrowRotateForward as rotate } from '@fortawesome/free-solid-svg-icons';

export default function Nav() {
    return (
        <nav>
            <img src={logo} width="100" />
            <ul className="links">
                <li className="sub">
                    <a href="#">[Division Name]</a>
                    <div className="sublinks">
                        <div className="section">
                            <div className="title">Modules <FontAwesomeIcon icon={gear} /></div>
                            <ul>
                                <li><a href="#">[Division Name] Overview</a></li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li className="sub">
                    <a href="#">ROSES</a>
                    <div className="sublinks">
                        <div className="section">
                            <div className="title">Modules <FontAwesomeIcon icon={gear} /></div>
                            <ul>
                                <li><a href="#">ROSES Dashboard</a></li>
                                <li><a href="#">Document Libraries</a></li>
                                <li><a href="#">ROSES Calendar</a></li>
                                <li><a href="#">Non-Recurring Elements</a></li>
                                <li><a href="#">All People</a></li>
                                <li><a href="#">All Proposals</a></li>
                                <li><a href="#">Elements Overview</a></li>
                                <li><a href="#">R&A Lead Dashboard</a></li>
                            </ul>
                        </div>
                        <div className="section">
                            <div className="title">Recurring Elements <FontAwesomeIcon icon={rotate} /></div>
                            <ul>
                                <li><a href="#">HIGO 2019</a></li>
                                <li><a href="#">RileyTest 2022</a></li>
                                <li><a href="#">Test 2022</a></li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li><a href="#">About</a></li>
                <li><a href="#">Admin Console</a></li>
                <li><a href="#">Report Center</a></li>
            </ul>
        </nav>
    );
}