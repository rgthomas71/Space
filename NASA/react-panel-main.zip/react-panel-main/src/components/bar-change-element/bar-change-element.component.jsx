import './bar-change-element.styles.scss';

export default function BarChangeElement({ setShowBar }) {
    return (
        <div>
            <h2><span>Change Element</span><button onClick={() => setShowBar(false)}>Close</button></h2>
            <section>
                <label htmlFor="element">ROSES Element</label>
                <select name="element" id="element">
                    <option>Select an Option</option>
                    <option selected>HGIO</option>
                    <option>RileyTest</option>
                </select>
                <label htmlFor="year">Solicitation Year</label>
                <select name="year" id="year">
                    <option>Select a Year</option>
                    <option selected>2019</option>
                </select>
            </section>
        </div>
    );
}