import './bar-panels.styles.scss';

export default function BarPanels({ setShowBar }) {
    return (
        <div>
            <h2><span>Panels</span><button onClick={() => setShowBar(false)}>Close</button></h2>
        </div>
    );
}