This repository contains the files demoed during the meeting on May 27th, 2022.

To install this repository locally:

1. Run this command ONE (1) time:

        npm i

2. Then, after installing the dependencies, run the following command every time you want to run the app on localhost:

        npm start